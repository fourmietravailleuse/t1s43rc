<?php
/*
Plugin Name: Creasit Rôles
Description: Gestion des rôles
Author: Creasit
Version: 1.0
*/


/**

Liens utile :
- http://codex.wordpress.org/Roles_and_Capabilities

*/



/**
I18N
*/
add_action( 'plugins_loaded', 'creasit_lang_init' );
function creasit_lang_init() {
	load_plugin_textdomain( 'default', false, basename( dirname( __FILE__ ) ) . '/languages' );
}


/**
Création du nouveau rôle
*/
register_activation_hook( __FILE__, 'creasit_ajout_role' );

function creasit_ajout_role() {
	// Creates a Owner User Role (editor level, with super-powers)
	if ( $editor = get_role('editor') ) {
		remove_role( 'webmestre' );
		add_role( 'webmestre', 'Webmestre', $editor->capabilities );

		$webmestre = get_role('webmestre');
		// Can manipulate users
		$webmestre->add_cap( 'list_users' );
		$webmestre->add_cap( 'create_users' );
		$webmestre->add_cap( 'edit_users' );
		$webmestre->add_cap( 'promote_users' );
		$webmestre->add_cap( 'delete_users' );
		$webmestre->add_cap( 'remove_users' );

		$webmestre->add_cap( 'edit_theme_options' );
		$webmestre->add_cap( 'manage_options' );

		// Gestion des plugins dans la sidebar
		$webmestre->add_cap( 'wysija_newsletters' );
	}
}


/**
Suppriemr des sous-menus inutiles 
*/

function creasit_menus() {
	global $submenu;
	global $current_user;

    $user_role = $current_user->roles[0];
    if($user_role != 'administrator') {

		function replace_menus() {
			global $menu;
			global $submenu;

			unset($menu[80]); // Supprimer le menu "Réglages"
			unset($submenu['options-general.php']); // Supprime les sous-menus de "Réglages"

			// Change le menu "Apparence" en "Menus"
			$menu[60] = array( __('Menus'), 'edit_theme_options', 'nav-menus.php', '', 'menu-top menu-icon-appearance', 'menu-appearance', 'dashicons-menu' ); 

			// Change le menu "Outils" en "Options du site"
			$menu[75] = array( __('Options du site'), 'edit_posts', 'themes.php?page=creasit-theme-option', '', 'menu-top menu-icon-tools', 'menu-tools', 'dashicons-admin-tools' );

		}

		add_action('admin_menu', 'replace_menus', 11);

	}
}
add_action('admin_menu', 'creasit_menus');